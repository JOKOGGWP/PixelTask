package com.example

import com.example.pixeltask.data.model.Task
import com.example.pixeltask.data.model.TaskFilter
import com.example.pixeltask.data.model.TaskPriority
import com.example.pixeltask.data.model.TaskSort
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PixelTaskUnitTest {

    @Test
    fun testTaskCreationAndDefaults() {
        val task = Task(
            title = "Defeat the Dragon",
            description = "Main quest objective",
            category = "GAME",
            priority = TaskPriority.HIGH,
            dueDate = null
        )

        assertEquals("Defeat the Dragon", task.title)
        assertEquals("Main quest objective", task.description)
        assertEquals("GAME", task.category)
        assertEquals(TaskPriority.HIGH, task.priority)
        assertFalse(task.completed)
    }

    @Test
    fun testTaskCompletionToggle() {
        val task = Task(
            title = "Craft Potion",
            description = "Alchemy",
            category = "STUDY",
            priority = TaskPriority.MEDIUM,
            completed = false
        )

        val completedTask = task.copy(completed = true)
        assertTrue(completedTask.completed)
    }

    @Test
    fun testPriorityOrdering() {
        assertTrue(TaskPriority.HIGH.level > TaskPriority.MEDIUM.level)
        assertTrue(TaskPriority.MEDIUM.level > TaskPriority.LOW.level)
    }

    @Test
    fun testTaskFilterLabels() {
        assertEquals("ALL", TaskFilter.ALL.label)
        assertEquals("ACTIVE", TaskFilter.ACTIVE.label)
        assertEquals("DONE", TaskFilter.COMPLETED.label)
    }

    @Test
    fun testTaskSortLabels() {
        assertEquals("NEWEST", TaskSort.NEWEST.label)
        assertEquals("OLDEST", TaskSort.OLDEST.label)
        assertEquals("PRIORITY", TaskSort.PRIORITY.label)
        assertEquals("DEADLINE", TaskSort.DUE_DATE.label)
    }
}
