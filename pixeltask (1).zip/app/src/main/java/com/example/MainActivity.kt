package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.pixeltask.data.database.AppDatabase
import com.example.pixeltask.data.model.Task
import com.example.pixeltask.data.preferences.UserPreferences
import com.example.pixeltask.data.repository.TaskRepositoryImpl
import com.example.pixeltask.data.sound.RetroSoundPlayer
import com.example.pixeltask.ui.components.NavDestination
import com.example.pixeltask.ui.components.PixelBottomBar
import com.example.pixeltask.ui.screens.AddEditTaskDialog
import com.example.pixeltask.ui.screens.HomeScreen
import com.example.pixeltask.ui.screens.SettingsScreen
import com.example.pixeltask.ui.screens.StatsScreen
import com.example.pixeltask.ui.screens.TasksScreen
import com.example.pixeltask.ui.theme.PixelTaskTheme
import com.example.pixeltask.ui.theme.PixelTheme
import com.example.pixeltask.viewmodel.TaskViewModel
import com.example.pixeltask.viewmodel.TaskViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getDatabase(applicationContext)
        val repository = TaskRepositoryImpl(database.taskDao())
        val preferences = UserPreferences(applicationContext)
        val soundPlayer = RetroSoundPlayer(applicationContext)

        val factory = TaskViewModelFactory(repository, preferences, soundPlayer)

        setContent {
            val taskViewModel: TaskViewModel = viewModel(factory = factory)
            val settings by taskViewModel.settings.collectAsStateWithLifecycle()

            PixelTaskTheme(themeMode = settings.themeMode) {
                PixelTaskApp(viewModel = taskViewModel)
            }
        }
    }
}

@Composable
fun PixelTaskApp(viewModel: TaskViewModel) {
    var currentDestination by remember { mutableStateOf(NavDestination.HOME) }
    var isAddEditOpen by remember { mutableStateOf(false) }
    var taskToEdit by remember { mutableStateOf<Task?>(null) }

    val settings by viewModel.settings.collectAsStateWithLifecycle()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            PixelBottomBar(
                currentDestination = currentDestination,
                onNavigate = { currentDestination = it }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = innerPadding.calculateBottomPadding())
                .background(PixelTheme.colors.background)
        ) {
            AnimatedContent(
                targetState = currentDestination,
                transitionSpec = {
                    if (settings.animationEnabled) {
                        (fadeIn(animationSpec = tween(200)) + scaleIn(initialScale = 0.97f, animationSpec = tween(200)))
                            .togetherWith(fadeOut(animationSpec = tween(150)) + scaleOut(targetScale = 1.02f, animationSpec = tween(150)))
                    } else {
                        fadeIn(animationSpec = tween(0)).togetherWith(fadeOut(animationSpec = tween(0)))
                    }
                },
                label = "page_navigation"
            ) { destination ->
                when (destination) {
                    NavDestination.HOME -> {
                        HomeScreen(
                            viewModel = viewModel,
                            onOpenAddTask = {
                                taskToEdit = null
                                isAddEditOpen = true
                            },
                            onOpenEditTask = { task ->
                                taskToEdit = task
                                isAddEditOpen = true
                            }
                        )
                    }
                    NavDestination.TASKS -> {
                        TasksScreen(
                            viewModel = viewModel,
                            onOpenAddTask = {
                                taskToEdit = null
                                isAddEditOpen = true
                            },
                            onOpenEditTask = { task ->
                                taskToEdit = task
                                isAddEditOpen = true
                            }
                        )
                    }
                    NavDestination.STATS -> {
                        StatsScreen(viewModel = viewModel)
                    }
                    NavDestination.SETTINGS -> {
                        SettingsScreen(viewModel = viewModel)
                    }
                }
            }

            // Add or Edit Quest Dialog
            if (isAddEditOpen) {
                AddEditTaskDialog(
                    taskToEdit = taskToEdit,
                    onDismiss = { isAddEditOpen = false },
                    onSave = { title, description, category, priority, dueDate ->
                        val existing = taskToEdit
                        if (existing != null) {
                            viewModel.updateTask(
                                existing.copy(
                                    title = title,
                                    description = description,
                                    category = category,
                                    priority = priority,
                                    dueDate = dueDate
                                )
                            )
                        } else {
                            viewModel.addTask(
                                title = title,
                                description = description,
                                category = category,
                                priority = priority,
                                dueDate = dueDate
                            )
                        }
                        isAddEditOpen = false
                    },
                    animationEnabled = settings.animationEnabled
                )
            }
        }
    }
}

// Retained for backwards compatibility with baseline tests
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}
