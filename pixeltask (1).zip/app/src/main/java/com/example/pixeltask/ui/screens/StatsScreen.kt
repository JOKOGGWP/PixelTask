package com.example.pixeltask.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.pixeltask.ui.components.PixelCard
import com.example.pixeltask.ui.components.PixelProgressBar
import com.example.pixeltask.ui.components.PixelTopBar
import com.example.pixeltask.ui.components.PixelTrophyIcon
import com.example.pixeltask.ui.components.pixelCornerShape
import com.example.pixeltask.ui.theme.PixelPalette
import com.example.pixeltask.ui.theme.PixelTheme
import com.example.pixeltask.viewmodel.Achievement
import com.example.pixeltask.viewmodel.TaskViewModel
import java.util.Calendar
import kotlin.math.roundToInt

@Composable
fun StatsScreen(
    viewModel: TaskViewModel,
    modifier: Modifier = Modifier
) {
    val stats by viewModel.stats.collectAsStateWithLifecycle()
    val achievements by viewModel.achievements.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PixelTheme.colors.background)
            .testTag("stats_screen")
    ) {
        PixelTopBar(
            title = "QUEST STATS",
            subtitle = "HEROIC METRICS & BADGES"
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Overall Stats Grid
            item(key = "overview_metrics") {
                PixelCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = PixelTheme.colors.surface,
                    accentColor = PixelTheme.colors.accent
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "COMMAND CENTER OVERVIEW",
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp,
                                letterSpacing = 1.sp,
                                color = PixelTheme.colors.accent
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            MetricBox(
                                label = "TOTAL",
                                value = stats.totalTasks.toString(),
                                modifier = Modifier.weight(1f)
                            )
                            MetricBox(
                                label = "DONE",
                                value = stats.completedTasks.toString(),
                                valueColor = PixelPalette.NeonMint,
                                modifier = Modifier.weight(1f)
                            )
                            MetricBox(
                                label = "ACTIVE",
                                value = stats.activeTasks.toString(),
                                valueColor = PixelPalette.NeonYellow,
                                modifier = Modifier.weight(1f)
                            )
                            MetricBox(
                                label = "RATE",
                                value = "${(stats.completionRate * 100).roundToInt()}%",
                                valueColor = PixelPalette.NeonCyan,
                                modifier = Modifier.weight(1.1f)
                            )
                        }
                    }
                }
            }

            // Pixel-art Day of Week Chart
            item(key = "pixel_chart") {
                PixelCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = PixelTheme.colors.surface,
                    accentColor = PixelTheme.colors.primary
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "WEEKLY ACTIVITY CHART",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 13.sp,
                                    letterSpacing = 1.sp,
                                    color = PixelTheme.colors.primary
                                )
                            )
                            Text(
                                text = "QUESTS LOGGED",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    color = PixelTheme.colors.textSecondary
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        val days = listOf(
                            Pair("MON", Calendar.MONDAY),
                            Pair("TUE", Calendar.TUESDAY),
                            Pair("WED", Calendar.WEDNESDAY),
                            Pair("THU", Calendar.THURSDAY),
                            Pair("FRI", Calendar.FRIDAY),
                            Pair("SAT", Calendar.SATURDAY),
                            Pair("SUN", Calendar.SUNDAY)
                        )

                        val maxCount = days.maxOfOrNull { stats.dayOfWeekCounts[it.second] ?: 0 }?.coerceAtLeast(1) ?: 1

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            days.forEach { (label, dayCode) ->
                                val count = stats.dayOfWeekCounts[dayCode] ?: 0
                                PixelChartRow(
                                    dayLabel = label,
                                    count = count,
                                    maxCount = maxCount,
                                    activeColor = PixelTheme.colors.primary
                                )
                            }
                        }
                    }
                }
            }

            // Category Distribution
            if (stats.categoryCounts.isNotEmpty()) {
                item(key = "category_breakdown") {
                    PixelCard(
                        modifier = Modifier.fillMaxWidth(),
                        backgroundColor = PixelTheme.colors.surface,
                        accentColor = PixelPalette.NeonPurple
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "QUEST CATEGORIES",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 13.sp,
                                    letterSpacing = 1.sp,
                                    color = PixelPalette.NeonPurple
                                )
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            stats.categoryCounts.forEach { (cat, count) ->
                                val ratio = if (stats.totalTasks > 0) count.toFloat() / stats.totalTasks.toFloat() else 0f
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = cat,
                                        style = TextStyle(
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = PixelTheme.colors.textPrimary
                                        ),
                                        modifier = Modifier.width(80.dp)
                                    )
                                    Box(modifier = Modifier.weight(1f)) {
                                        PixelProgressBar(
                                            progress = ratio,
                                            segments = 12,
                                            barHeight = 12.dp,
                                            showLabel = false,
                                            animationEnabled = settings.animationEnabled,
                                            activeColor = PixelPalette.NeonPurple
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = "$count",
                                        style = TextStyle(
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Black,
                                            fontSize = 12.sp,
                                            color = PixelPalette.NeonYellow
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Achievements Section Header
            item(key = "achievements_header") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp, bottom = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PixelTrophyIcon(size = 18.dp, tint = PixelPalette.NeonYellow)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "HEROIC ACHIEVEMENTS",
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            letterSpacing = 0.5.sp,
                            color = PixelTheme.colors.textPrimary
                        )
                    )
                }
            }

            // Achievements list
            items(achievements, key = { it.id }) { ach ->
                AchievementItemCard(achievement = ach, animationEnabled = settings.animationEnabled)
            }

            item(key = "bottom_spacer") {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun MetricBox(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    valueColor: Color = PixelTheme.colors.textPrimary
) {
    Box(
        modifier = modifier
            .background(PixelTheme.colors.surfaceVariant)
            .padding(vertical = 8.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = value,
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    color = valueColor
                )
            )
            Text(
                text = label,
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.sp,
                    letterSpacing = 0.5.sp,
                    color = PixelTheme.colors.textSecondary
                )
            )
        }
    }
}

@Composable
private fun PixelChartRow(
    dayLabel: String,
    count: Int,
    maxCount: Int,
    activeColor: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = dayLabel,
            style = TextStyle(
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 11.sp,
                color = PixelTheme.colors.textSecondary
            ),
            modifier = Modifier.width(36.dp)
        )

        // Pixel Bar
        Canvas(
            modifier = Modifier
                .weight(1f)
                .height(14.dp)
        ) {
            val totalW = size.width
            val totalH = size.height
            val maxBlocks = 12
            val blockRatio = if (maxCount > 0) count.toFloat() / maxCount.toFloat() else 0f
            val filledBlocks = (blockRatio * maxBlocks).roundToInt()

            val blockW = (totalW - 2.dp.toPx() * (maxBlocks - 1)) / maxBlocks

            for (i in 0 until maxBlocks) {
                val isFilled = i < filledBlocks
                val x = i * (blockW + 2.dp.toPx())

                drawRect(
                    color = if (isFilled) activeColor else Color.Black.copy(alpha = 0.2f),
                    topLeft = Offset(x, 0f),
                    size = Size(blockW, totalH)
                )

                if (isFilled) {
                    drawRect(
                        color = Color.White.copy(alpha = 0.4f),
                        topLeft = Offset(x, 0f),
                        size = Size(blockW, totalH * 0.35f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.width(10.dp))

        Text(
            text = "$count",
            style = TextStyle(
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 11.sp,
                color = if (count > 0) PixelPalette.NeonMint else PixelTheme.colors.textMuted
            ),
            modifier = Modifier.width(24.dp)
        )
    }
}

@Composable
private fun AchievementItemCard(
    achievement: Achievement,
    animationEnabled: Boolean
) {
    PixelCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = if (achievement.isUnlocked) PixelTheme.colors.surface else PixelTheme.colors.surface.copy(alpha = 0.6f),
        accentColor = if (achievement.isUnlocked) PixelPalette.NeonYellow else PixelTheme.colors.borderShadow
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Trophy or Lock Icon
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(if (achievement.isUnlocked) PixelPalette.NeonYellow.copy(alpha = 0.15f) else PixelTheme.colors.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                PixelTrophyIcon(
                    size = 24.dp,
                    tint = if (achievement.isUnlocked) PixelPalette.NeonYellow else PixelTheme.colors.textMuted
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = achievement.title,
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp,
                            letterSpacing = 0.5.sp,
                            color = if (achievement.isUnlocked) PixelPalette.NeonYellow else PixelTheme.colors.textSecondary
                        )
                    )

                    // Unlocked / Locked Badge
                    val badgeColor = if (achievement.isUnlocked) PixelPalette.NeonMint else PixelTheme.colors.surfaceVariant
                    val badgeTextColor = if (achievement.isUnlocked) Color.Black else PixelTheme.colors.textMuted
                    val shape = pixelCornerShape(2.dp)
                    Box(
                        modifier = Modifier
                            .background(badgeColor, shape)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (achievement.isUnlocked) "UNLOCKED" else "LOCKED",
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Black,
                                fontSize = 9.sp,
                                color = badgeTextColor
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = achievement.description,
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Normal,
                        fontSize = 11.sp,
                        color = PixelTheme.colors.textSecondary
                    )
                )

                if (!achievement.isUnlocked) {
                    Spacer(modifier = Modifier.height(6.dp))
                    PixelProgressBar(
                        progress = achievement.progress,
                        segments = 10,
                        barHeight = 8.dp,
                        showLabel = false,
                        animationEnabled = animationEnabled,
                        activeColor = PixelPalette.NeonYellow
                    )
                }
            }
        }
    }
}
