package com.example.pixeltask.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.pixeltask.data.model.Task
import com.example.pixeltask.data.model.TaskFilter
import com.example.pixeltask.data.model.TaskPriority
import com.example.pixeltask.data.model.TaskSort
import com.example.pixeltask.data.preferences.AppThemeMode
import com.example.pixeltask.data.preferences.UserPreferences
import com.example.pixeltask.data.preferences.UserSettings
import com.example.pixeltask.data.repository.TaskRepository
import com.example.pixeltask.data.sound.RetroSoundPlayer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

data class TaskStats(
    val totalTasks: Int = 0,
    val completedTasks: Int = 0,
    val activeTasks: Int = 0,
    val completionRate: Float = 0f,
    val categoryCounts: Map<String, Int> = emptyMap(),
    val dayOfWeekCounts: Map<Int, Int> = emptyMap() // Calendar.DAY_OF_WEEK -> count
)

data class Achievement(
    val id: String,
    val title: String,
    val description: String,
    val isUnlocked: Boolean,
    val progress: Float // 0f to 1f
)

class TaskViewModel(
    private val repository: TaskRepository,
    private val preferences: UserPreferences,
    private val soundPlayer: RetroSoundPlayer
) : ViewModel() {

    val settings: StateFlow<UserSettings> = preferences.settings

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedFilter = MutableStateFlow(TaskFilter.ALL)
    val selectedFilter: StateFlow<TaskFilter> = _selectedFilter.asStateFlow()

    private val _selectedSort = MutableStateFlow(TaskSort.NEWEST)
    val selectedSort: StateFlow<TaskSort> = _selectedSort.asStateFlow()

    private val _selectedCategory = MutableStateFlow<String?>(null)
    val selectedCategory: StateFlow<String?> = _selectedCategory.asStateFlow()

    // All raw tasks from Room database
    val allTasks: StateFlow<List<Task>> = repository.getAllTasks()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Filtered & Sorted tasks for display
    val displayedTasks: StateFlow<List<Task>> = combine(
        allTasks,
        _searchQuery,
        _selectedFilter,
        _selectedSort,
        _selectedCategory
    ) { tasks, query, filter, sort, category ->
        var list = tasks

        // 1. Search Query
        if (query.isNotBlank()) {
            val q = query.trim().lowercase()
            list = list.filter {
                it.title.lowercase().contains(q) ||
                it.description.lowercase().contains(q) ||
                it.category.lowercase().contains(q)
            }
        }

        // 2. Status Filter
        list = when (filter) {
            TaskFilter.ALL -> list
            TaskFilter.ACTIVE -> list.filter { !it.completed }
            TaskFilter.COMPLETED -> list.filter { it.completed }
        }

        // 3. Category Filter
        if (category != null) {
            list = list.filter { it.category.equals(category, ignoreCase = true) }
        }

        // 4. Sorting
        when (sort) {
            TaskSort.NEWEST -> list.sortedByDescending { it.createdAt }
            TaskSort.OLDEST -> list.sortedBy { it.createdAt }
            TaskSort.PRIORITY -> list.sortedByDescending { it.priority.level }
            TaskSort.DUE_DATE -> list.sortedWith(
                compareBy(nullsLast()) { it.dueDate }
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Daily & Overall Stats
    val stats: StateFlow<TaskStats> = allTasks.combine(_selectedFilter) { tasks, _ ->
        val total = tasks.size
        val completed = tasks.count { it.completed }
        val active = total - completed
        val rate = if (total > 0) completed.toFloat() / total.toFloat() else 0f

        val catMap = tasks.groupBy { it.category.uppercase() }.mapValues { it.value.size }

        val dayMap = mutableMapOf<Int, Int>()
        tasks.forEach { task ->
            val cal = Calendar.getInstance().apply { timeInMillis = task.createdAt }
            val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
            dayMap[dayOfWeek] = (dayMap[dayOfWeek] ?: 0) + 1
        }

        TaskStats(
            totalTasks = total,
            completedTasks = completed,
            activeTasks = active,
            completionRate = rate,
            categoryCounts = catMap,
            dayOfWeekCounts = dayMap
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = TaskStats()
    )

    // Achievements calculation
    val achievements: StateFlow<List<Achievement>> = allTasks.combine(_selectedFilter) { tasks, _ ->
        val completedCount = tasks.count { it.completed }
        val totalCount = tasks.size
        val categoriesCount = tasks.map { it.category.uppercase() }.distinct().size

        listOf(
            Achievement(
                id = "first_quest",
                title = "FIRST QUEST",
                description = "Complete your first task.",
                isUnlocked = completedCount >= 1,
                progress = (completedCount.toFloat() / 1f).coerceIn(0f, 1f)
            ),
            Achievement(
                id = "task_warrior",
                title = "TASK WARRIOR",
                description = "Complete 10 quests.",
                isUnlocked = completedCount >= 10,
                progress = (completedCount.toFloat() / 10f).coerceIn(0f, 1f)
            ),
            Achievement(
                id = "pixel_master",
                title = "PIXEL MASTER",
                description = "Complete 50 quests.",
                isUnlocked = completedCount >= 50,
                progress = (completedCount.toFloat() / 50f).coerceIn(0f, 1f)
            ),
            Achievement(
                id = "perfect_day",
                title = "PERFECT DAY",
                description = "Complete all tasks in your quest log.",
                isUnlocked = totalCount > 0 && completedCount == totalCount,
                progress = if (totalCount > 0) completedCount.toFloat() / totalCount else 0f
            ),
            Achievement(
                id = "master_organizer",
                title = "ORGANIZER",
                description = "Create tasks across 3 or more categories.",
                isUnlocked = categoriesCount >= 3,
                progress = (categoriesCount.toFloat() / 3f).coerceIn(0f, 1f)
            )
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun addTask(
        title: String,
        description: String,
        category: String,
        priority: TaskPriority,
        dueDate: Long?
    ) {
        viewModelScope.launch {
            val task = Task(
                title = title,
                description = description,
                category = category,
                priority = priority,
                dueDate = dueDate,
                createdAt = System.currentTimeMillis(),
                completed = false
            )
            repository.insertTask(task)
            soundPlayer.playTaskCreated(
                soundEnabled = settings.value.soundEnabled,
                vibrationEnabled = settings.value.vibrationEnabled
            )
        }
    }

    fun updateTask(task: Task) {
        viewModelScope.launch {
            repository.updateTask(task)
            soundPlayer.playButtonClick(
                soundEnabled = settings.value.soundEnabled,
                vibrationEnabled = settings.value.vibrationEnabled
            )
        }
    }

    fun toggleTaskComplete(task: Task, completed: Boolean) {
        viewModelScope.launch {
            repository.setTaskCompleted(task.id, completed)
            if (completed) {
                soundPlayer.playTaskCompleted(
                    soundEnabled = settings.value.soundEnabled,
                    vibrationEnabled = settings.value.vibrationEnabled
                )
            } else {
                soundPlayer.playButtonClick(
                    soundEnabled = settings.value.soundEnabled,
                    vibrationEnabled = settings.value.vibrationEnabled
                )
            }
        }
    }

    fun deleteTask(task: Task) {
        viewModelScope.launch {
            repository.deleteTask(task)
            soundPlayer.playTaskDeleted(
                soundEnabled = settings.value.soundEnabled,
                vibrationEnabled = settings.value.vibrationEnabled
            )
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFilter(filter: TaskFilter) {
        _selectedFilter.value = filter
        soundPlayer.playButtonClick(
            soundEnabled = settings.value.soundEnabled,
            vibrationEnabled = settings.value.vibrationEnabled
        )
    }

    fun setSort(sort: TaskSort) {
        _selectedSort.value = sort
        soundPlayer.playButtonClick(
            soundEnabled = settings.value.soundEnabled,
            vibrationEnabled = settings.value.vibrationEnabled
        )
    }

    fun setCategory(category: String?) {
        _selectedCategory.value = category
        soundPlayer.playButtonClick(
            soundEnabled = settings.value.soundEnabled,
            vibrationEnabled = settings.value.vibrationEnabled
        )
    }

    fun setThemeMode(mode: AppThemeMode) {
        preferences.setThemeMode(mode)
    }

    fun setAnimationEnabled(enabled: Boolean) {
        preferences.setAnimationEnabled(enabled)
    }

    fun setSoundEnabled(enabled: Boolean) {
        preferences.setSoundEnabled(enabled)
    }

    fun setVibrationEnabled(enabled: Boolean) {
        preferences.setVibrationEnabled(enabled)
    }
}

class TaskViewModelFactory(
    private val repository: TaskRepository,
    private val preferences: UserPreferences,
    private val soundPlayer: RetroSoundPlayer
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(TaskViewModel::class.java)) {
            return TaskViewModel(repository, preferences, soundPlayer) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
