package com.example.pixeltask.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import com.example.pixeltask.ui.theme.PixelPalette
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private data class PixelParticle(
    val angle: Double,
    val speed: Float,
    val size: Float,
    val color: Color,
    val rotationSpeed: Float,
    val initialOffset: Offset
)

@Composable
fun PixelParticleEffect(
    trigger: Boolean,
    modifier: Modifier = Modifier,
    particleCount: Int = 16,
    durationMs: Int = 550,
    colors: List<Color> = listOf(
        PixelPalette.NeonCyan,
        PixelPalette.NeonMint,
        PixelPalette.NeonYellow,
        PixelPalette.NeonPink,
        Color.White
    ),
    onAnimationEnd: () -> Unit = {}
) {
    var isRunning by remember { mutableStateOf(false) }
    val progress = remember { Animatable(0f) }
    var particles by remember { mutableStateOf<List<PixelParticle>>(emptyList()) }

    LaunchedEffect(trigger) {
        if (trigger) {
            val random = Random(System.currentTimeMillis())
            particles = List(particleCount) {
                val angle = random.nextDouble(0.0, Math.PI * 2.0)
                val speed = random.nextFloat() * 180f + 60f
                val size = random.nextFloat() * 10f + 6f
                val color = colors[random.nextInt(colors.size)]
                val rot = (random.nextFloat() - 0.5f) * 360f
                PixelParticle(
                    angle = angle,
                    speed = speed,
                    size = size,
                    color = color,
                    rotationSpeed = rot,
                    initialOffset = Offset.Zero
                )
            }
            isRunning = true
            progress.snapTo(0f)
            progress.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = durationMs, easing = FastOutSlowInEasing)
            )
            isRunning = false
            onAnimationEnd()
        }
    }

    if (isRunning && particles.isNotEmpty()) {
        Canvas(modifier = modifier.fillMaxSize()) {
            val currentProgress = progress.value
            val center = Offset(size.width / 2f, size.height / 2f)
            val alpha = (1f - currentProgress).coerceIn(0f, 1f)

            particles.forEach { p ->
                val distance = p.speed * currentProgress
                val gravity = 120f * (currentProgress * currentProgress)
                val px = center.x + (cos(p.angle) * distance).toFloat()
                val py = center.y + (sin(p.angle) * distance).toFloat() + gravity

                rotate(
                    degrees = p.rotationSpeed * currentProgress,
                    pivot = Offset(px + p.size / 2f, py + p.size / 2f)
                ) {
                    drawRect(
                        color = p.color.copy(alpha = alpha),
                        topLeft = Offset(px, py),
                        size = Size(p.size, p.size)
                    )
                }
            }
        }
    }
}
