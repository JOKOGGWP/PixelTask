package com.example.pixeltask.data.preferences

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class AppThemeMode {
    DARK,
    LIGHT,
    SYSTEM
}

data class UserSettings(
    val themeMode: AppThemeMode = AppThemeMode.DARK,
    val animationEnabled: Boolean = true,
    val soundEnabled: Boolean = false,
    val vibrationEnabled: Boolean = true
)

class UserPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("pixeltask_settings", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<UserSettings> = _settings.asStateFlow()

    private fun loadSettings(): UserSettings {
        val themeName = prefs.getString("theme_mode", AppThemeMode.DARK.name) ?: AppThemeMode.DARK.name
        val theme = try {
            AppThemeMode.valueOf(themeName)
        } catch (_: Exception) {
            AppThemeMode.DARK
        }
        val animation = prefs.getBoolean("animation_enabled", true)
        val sound = prefs.getBoolean("sound_enabled", false)
        val vibration = prefs.getBoolean("vibration_enabled", true)

        return UserSettings(
            themeMode = theme,
            animationEnabled = animation,
            soundEnabled = sound,
            vibrationEnabled = vibration
        )
    }

    fun setThemeMode(themeMode: AppThemeMode) {
        prefs.edit().putString("theme_mode", themeMode.name).apply()
        _settings.value = _settings.value.copy(themeMode = themeMode)
    }

    fun setAnimationEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("animation_enabled", enabled).apply()
        _settings.value = _settings.value.copy(animationEnabled = enabled)
    }

    fun setSoundEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("sound_enabled", enabled).apply()
        _settings.value = _settings.value.copy(soundEnabled = enabled)
    }

    fun setVibrationEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("vibration_enabled", enabled).apply()
        _settings.value = _settings.value.copy(vibrationEnabled = enabled)
    }
}
