package com.example.pixeltask.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pixeltask.ui.theme.PixelPalette
import com.example.pixeltask.ui.theme.PixelTheme
import kotlin.math.roundToInt

@Composable
fun PixelProgressBar(
    progress: Float, // 0.0f to 1.0f
    modifier: Modifier = Modifier,
    barHeight: Dp = 16.dp,
    segments: Int = 16,
    showLabel: Boolean = true,
    animationEnabled: Boolean = true,
    activeColor: Color = PixelTheme.colors.primary
) {
    val animatedProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = if (animationEnabled) tween(durationMillis = 400) else tween(durationMillis = 0),
        label = "pixel_progress"
    )

    val filledSegments = (animatedProgress * segments).roundToInt().coerceIn(0, segments)
    val percentageInt = (animatedProgress * 100).roundToInt()

    val borderColor = PixelTheme.colors.border
    val inactiveBlockColor = PixelTheme.colors.surfaceVariant

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (showLabel) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "DAILY QUEST PROGRESS",
                    style = PixelTheme.colors.let {
                        androidx.compose.ui.text.TextStyle(
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 0.5.sp,
                            color = PixelTheme.colors.textSecondary
                        )
                    }
                )
                Text(
                    text = "$percentageInt%",
                    style = androidx.compose.ui.text.TextStyle(
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Black,
                        fontSize = 13.sp,
                        letterSpacing = 0.5.sp,
                        color = activeColor
                    )
                )
            }
        }

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(barHeight)
        ) {
            val totalW = size.width
            val totalH = size.height
            val borderThick = 2.dp.toPx()

            // Outer Frame
            drawRect(
                color = borderColor,
                topLeft = Offset.Zero,
                size = Size(totalW, totalH)
            )

            // Inner area
            val innerW = totalW - borderThick * 2
            val innerH = totalH - borderThick * 2
            val gap = 2.dp.toPx()
            val segmentW = (innerW - (gap * (segments - 1))) / segments

            var currentX = borderThick
            for (i in 0 until segments) {
                val isFilled = i < filledSegments
                val blockColor = if (isFilled) {
                    when {
                        progress >= 1f -> PixelPalette.NeonMint
                        progress >= 0.6f -> activeColor
                        progress >= 0.3f -> PixelPalette.NeonYellow
                        else -> PixelPalette.NeonPink
                    }
                } else {
                    inactiveBlockColor
                }

                // Draw Block
                drawRect(
                    color = blockColor,
                    topLeft = Offset(currentX, borderThick),
                    size = Size(segmentW, innerH)
                )

                // Draw Top Bevel highlight on filled block
                if (isFilled) {
                    drawRect(
                        color = Color.White.copy(alpha = 0.4f),
                        topLeft = Offset(currentX, borderThick),
                        size = Size(segmentW, innerH * 0.3f)
                    )
                }

                currentX += segmentW + gap
            }
        }
    }
}
