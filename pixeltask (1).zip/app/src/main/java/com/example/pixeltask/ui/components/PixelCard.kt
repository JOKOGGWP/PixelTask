package com.example.pixeltask.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.pixeltask.ui.theme.PixelTheme

@Composable
fun PixelCard(
    modifier: Modifier = Modifier,
    backgroundColor: Color = PixelTheme.colors.surface,
    borderColor: Color = PixelTheme.colors.border,
    accentColor: Color? = null,
    cornerSize: Dp = 4.dp,
    borderWidth: Dp = 2.dp,
    elevationShadow: Boolean = true,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = pixelCornerShape(cornerSize)
    val shadowOffset = if (elevationShadow) 3.dp else 0.dp

    Box(
        modifier = modifier
            .padding(bottom = shadowOffset, end = if (elevationShadow) 2.dp else 0.dp)
            .then(
                if (elevationShadow) {
                    Modifier.drawBehind {
                        val w = size.width
                        val h = size.height
                        val sPx = shadowOffset.toPx()
                        // 8-bit drop shadow
                        drawRect(
                            color = borderColor.copy(alpha = 0.8f),
                            topLeft = Offset(2.dp.toPx(), sPx),
                            size = Size(w, h)
                        )
                    }
                } else Modifier
            )
            .clip(shape)
            .background(backgroundColor)
            .border(borderWidth, borderColor, shape)
            .then(
                if (accentColor != null) {
                    Modifier.drawBehind {
                        // Left pixel accent strip
                        drawRect(
                            color = accentColor,
                            topLeft = Offset.Zero,
                            size = Size(4.dp.toPx(), size.height)
                        )
                    }
                } else Modifier
            )
    ) {
        content()
    }
}
