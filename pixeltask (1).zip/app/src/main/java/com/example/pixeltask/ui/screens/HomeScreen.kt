package com.example.pixeltask.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.pixeltask.data.model.Task
import com.example.pixeltask.ui.components.PixelButton
import com.example.pixeltask.ui.components.PixelButtonVariant
import com.example.pixeltask.ui.components.PixelCard
import com.example.pixeltask.ui.components.PixelEmptyState
import com.example.pixeltask.ui.components.PixelPlusIcon
import com.example.pixeltask.ui.components.PixelProgressBar
import com.example.pixeltask.ui.components.PixelTaskItem
import com.example.pixeltask.ui.components.PixelTopBar
import com.example.pixeltask.ui.theme.PixelPalette
import com.example.pixeltask.ui.theme.PixelTheme
import com.example.pixeltask.viewmodel.TaskViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    viewModel: TaskViewModel,
    onOpenAddTask: () -> Unit,
    onOpenEditTask: (Task) -> Unit,
    modifier: Modifier = Modifier
) {
    val tasks by viewModel.allTasks.collectAsStateWithLifecycle()
    val stats by viewModel.stats.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    val todayDateFormatted = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault())
        .format(Date())
        .uppercase()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PixelTheme.colors.background)
            .testTag("home_screen")
    ) {
        PixelTopBar(
            title = "PIXELTASK",
            subtitle = "DAILY QUEST BOARD",
            actions = {
                PixelButton(
                    text = "+ NEW",
                    onClick = onOpenAddTask,
                    variant = PixelButtonVariant.PRIMARY,
                    icon = { PixelPlusIcon(size = 12.dp) },
                    testTag = "home_quick_add_button"
                )
            }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Daily Quest Overview Banner
            item(key = "daily_overview_card") {
                PixelCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = PixelTheme.colors.surface,
                    accentColor = PixelTheme.colors.primary
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "TODAY'S SUMMARY",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 13.sp,
                                    letterSpacing = 1.sp,
                                    color = PixelTheme.colors.primary
                                )
                            )
                            Text(
                                text = todayDateFormatted,
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    color = PixelTheme.colors.textSecondary
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Stats counters row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            StatCounterBox(
                                label = "TOTAL",
                                value = stats.totalTasks.toString(),
                                modifier = Modifier.weight(1f)
                            )
                            StatCounterBox(
                                label = "DONE",
                                value = stats.completedTasks.toString(),
                                valueColor = PixelPalette.NeonMint,
                                modifier = Modifier.weight(1f)
                            )
                            StatCounterBox(
                                label = "ACTIVE",
                                value = stats.activeTasks.toString(),
                                valueColor = PixelPalette.NeonYellow,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Daily Progress Bar
                        PixelProgressBar(
                            progress = stats.completionRate,
                            segments = 14,
                            animationEnabled = settings.animationEnabled,
                            activeColor = PixelTheme.colors.primary
                        )
                    }
                }
            }

            // Quests Section Header
            item(key = "quests_header") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp, bottom = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ACTIVE QUEST LOG",
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            letterSpacing = 0.5.sp,
                            color = PixelTheme.colors.textPrimary
                        )
                    )
                    Text(
                        text = "${stats.activeTasks} PENDING",
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = PixelTheme.colors.textSecondary
                        )
                    )
                }
            }

            // Tasks list or Empty State
            if (tasks.isEmpty()) {
                item(key = "empty_state") {
                    PixelEmptyState(
                        title = "NO QUESTS FOUND",
                        subtitle = "Your quest backlog is empty. Tap below to embark on a new quest!",
                        onNewTaskClick = onOpenAddTask
                    )
                }
            } else {
                items(tasks, key = { it.id }) { task ->
                    PixelTaskItem(
                        task = task,
                        onToggleComplete = { completed ->
                            viewModel.toggleTaskComplete(task, completed)
                        },
                        onEdit = { onOpenEditTask(task) },
                        onDelete = { viewModel.deleteTask(task) },
                        animationEnabled = settings.animationEnabled
                    )
                }
            }

            item(key = "bottom_spacer") {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun StatCounterBox(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    valueColor: androidx.compose.ui.graphics.Color = PixelTheme.colors.textPrimary
) {
    Box(
        modifier = modifier
            .background(PixelTheme.colors.surfaceVariant)
            .padding(vertical = 8.dp, horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = value,
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    color = valueColor
                )
            )
            Text(
                text = label,
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.sp,
                    letterSpacing = 0.5.sp,
                    color = PixelTheme.colors.textSecondary
                )
            )
        }
    }
}
