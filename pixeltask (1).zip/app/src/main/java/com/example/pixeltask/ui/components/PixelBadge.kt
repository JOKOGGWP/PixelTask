package com.example.pixeltask.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pixeltask.data.model.TaskPriority
import com.example.pixeltask.ui.theme.PixelPalette
import com.example.pixeltask.ui.theme.PixelTheme

@Composable
fun PixelPriorityBadge(
    priority: TaskPriority,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor) = when (priority) {
        TaskPriority.HIGH -> Pair(PixelPalette.NeonPink, Color.White)
        TaskPriority.MEDIUM -> Pair(PixelPalette.NeonYellow, Color(0xFF1F1800))
        TaskPriority.LOW -> Pair(PixelPalette.NeonMint, Color(0xFF002913))
    }

    val shape = pixelCornerShape(2.dp)

    Box(
        modifier = modifier
            .clip(shape)
            .background(bgColor)
            .border(1.5.dp, PixelTheme.colors.border, shape)
            .padding(horizontal = 6.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = priority.label,
            style = TextStyle(
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 10.sp,
                letterSpacing = 0.5.sp,
                color = textColor
            )
        )
    }
}

@Composable
fun PixelCategoryBadge(
    category: String,
    modifier: Modifier = Modifier,
    customColor: Color? = null
) {
    val catColor = customColor ?: when (category.uppercase()) {
        "WORK" -> PixelPalette.CatWork
        "PERSONAL" -> PixelPalette.CatPersonal
        "GAME" -> PixelPalette.CatGame
        "STUDY" -> PixelPalette.CatStudy
        "HEALTH" -> PixelPalette.CatHealth
        else -> PixelPalette.CatOther
    }

    val shape = pixelCornerShape(2.dp)

    Box(
        modifier = modifier
            .clip(shape)
            .background(catColor.copy(alpha = 0.18f))
            .border(1.5.dp, catColor, shape)
            .padding(horizontal = 6.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = category.uppercase(),
            style = TextStyle(
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                letterSpacing = 0.5.sp,
                color = catColor
            )
        )
    }
}
