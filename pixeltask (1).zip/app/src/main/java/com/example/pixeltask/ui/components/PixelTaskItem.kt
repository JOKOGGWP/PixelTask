package com.example.pixeltask.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pixeltask.data.model.Task
import com.example.pixeltask.data.model.TaskPriority
import com.example.pixeltask.ui.theme.PixelPalette
import com.example.pixeltask.ui.theme.PixelTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun PixelTaskItem(
    task: Task,
    onToggleComplete: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier,
    animationEnabled: Boolean = true
) {
    val coroutineScope = rememberCoroutineScope()
    var isDeleting by remember { mutableStateOf(false) }
    var showCompletionParticles by remember { mutableStateOf(false) }
    var showDeleteParticles by remember { mutableStateOf(false) }
    val deleteOffsetX = remember { Animatable(0f) }
    val deleteAlpha = remember { Animatable(1f) }

    // Card scale animation on completion toggle
    var cardScaleTarget by remember { mutableStateOf(1f) }
    val cardScale by animateFloatAsState(
        targetValue = cardScaleTarget,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "task_card_scale"
    )

    fun executeDelete() {
        if (!animationEnabled) {
            onDelete()
            return
        }
        isDeleting = true
        showDeleteParticles = true
        coroutineScope.launch {
            // Task slightly shifts right and fades out with fragments
            launch { deleteOffsetX.animateTo(24f, tween(250)) }
            launch { deleteAlpha.animateTo(0f, tween(300)) }
            delay(320)
            onDelete()
        }
    }

    val priorityColor = when (task.priority) {
        TaskPriority.HIGH -> PixelPalette.NeonPink
        TaskPriority.MEDIUM -> PixelPalette.NeonYellow
        TaskPriority.LOW -> PixelPalette.NeonMint
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .testTag("task_item_${task.id}")
            .offset { IntOffset(deleteOffsetX.value.roundToInt(), 0) }
            .alpha(deleteAlpha.value)
            .scale(if (animationEnabled) cardScale else 1f)
    ) {
        PixelCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = if (task.completed) {
                PixelTheme.colors.surface.copy(alpha = 0.65f)
            } else {
                PixelTheme.colors.surface
            },
            accentColor = priorityColor,
            elevationShadow = !task.completed
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 12.dp, end = 8.dp, top = 12.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Pixel Checkbox with celebration trigger
                Box(contentAlignment = Alignment.Center) {
                    PixelCheckbox(
                        checked = task.completed,
                        onCheckedChange = { newChecked ->
                            if (!task.completed && newChecked && animationEnabled) {
                                showCompletionParticles = true
                                cardScaleTarget = 1.04f
                                coroutineScope.launch {
                                    delay(200)
                                    cardScaleTarget = 1f
                                }
                            }
                            onToggleComplete(newChecked)
                        },
                        animationEnabled = animationEnabled
                    )

                    if (animationEnabled) {
                        PixelParticleEffect(
                            trigger = showCompletionParticles,
                            particleCount = 14,
                            durationMs = 500,
                            colors = listOf(PixelPalette.NeonMint, PixelPalette.NeonCyan, Color.White),
                            onAnimationEnd = { showCompletionParticles = false }
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Task Details
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onEdit() }
                ) {
                    // Badges row: Category + Priority + Due Date
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PixelCategoryBadge(category = task.category)
                        PixelPriorityBadge(priority = task.priority)

                        if (task.dueDate != null) {
                            val formattedDate = formatDueDate(task.dueDate)
                            Text(
                                text = "⏰ $formattedDate",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    color = if (task.dueDate < System.currentTimeMillis() && !task.completed) {
                                        PixelPalette.NeonPink
                                    } else {
                                        PixelTheme.colors.textSecondary
                                    }
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Title
                    Text(
                        text = task.title,
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            letterSpacing = 0.25.sp,
                            textDecoration = if (task.completed) TextDecoration.LineThrough else TextDecoration.None,
                            color = if (task.completed) PixelTheme.colors.textMuted else PixelTheme.colors.textPrimary
                        ),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    // Description if available
                    if (task.description.isNotBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = task.description,
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Normal,
                                fontSize = 11.sp,
                                textDecoration = if (task.completed) TextDecoration.LineThrough else TextDecoration.None,
                                color = PixelTheme.colors.textMuted
                            ),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Action Buttons: Edit and Delete
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("edit_task_${task.id}")
                    ) {
                        PixelEditIcon(
                            size = 16.dp,
                            tint = PixelTheme.colors.textSecondary
                        )
                    }

                    IconButton(
                        onClick = { executeDelete() },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("delete_task_${task.id}")
                    ) {
                        PixelTrashIcon(
                            size = 16.dp,
                            tint = PixelPalette.NeonPink
                        )
                    }
                }
            }
        }

        // Delete Particle explosion
        if (animationEnabled && showDeleteParticles) {
            PixelParticleEffect(
                trigger = showDeleteParticles,
                particleCount = 18,
                durationMs = 400,
                colors = listOf(PixelPalette.NeonPink, Color.Black, PixelPalette.NeonYellow),
                onAnimationEnd = { showDeleteParticles = false }
            )
        }
    }
}

private fun formatDueDate(timestamp: Long): String {
    val date = Date(timestamp)
    val now = System.currentTimeMillis()
    val diff = timestamp - now
    val oneDayMs = 24 * 60 * 60 * 1000

    return when {
        diff in 0..oneDayMs -> "TODAY"
        diff in oneDayMs..(2 * oneDayMs) -> "TOMORROW"
        else -> SimpleDateFormat("dd MMM", Locale.getDefault()).format(date).uppercase()
    }
}
