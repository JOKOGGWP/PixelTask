package com.example.pixeltask.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pixeltask.ui.theme.PixelPalette
import com.example.pixeltask.ui.theme.PixelTheme

@Composable
fun PixelEmptyState(
    title: String = "NO QUESTS YET",
    subtitle: String = "Your quest log is clear. Create a task to start your adventure!",
    onNewTaskClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Pixel Art Quest Chest / Scroll Illustration
        PixelChestIllustration(size = 96.dp)

        Spacer(modifier = Modifier.height(18.dp))

        Text(
            text = title,
            style = TextStyle(
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 18.sp,
                letterSpacing = 1.sp,
                color = PixelTheme.colors.primary,
                textAlign = TextAlign.Center
            )
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = subtitle,
            style = TextStyle(
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Normal,
                fontSize = 12.sp,
                letterSpacing = 0.25.sp,
                color = PixelTheme.colors.textSecondary,
                textAlign = TextAlign.Center
            )
        )

        Spacer(modifier = Modifier.height(22.dp))

        PixelButton(
            text = "+ NEW TASK",
            onClick = onNewTaskClick,
            variant = PixelButtonVariant.PRIMARY,
            icon = { PixelPlusIcon(size = 14.dp, tint = Color.Black) },
            testTag = "empty_state_new_task_button"
        )
    }
}

@Composable
fun PixelChestIllustration(
    size: Dp = 96.dp,
    modifier: Modifier = Modifier
) {
    val gold = PixelPalette.NeonYellow
    val wood = Color(0xFFC07020)
    val darkWood = Color(0xFF7A4010)
    val iron = Color(0xFF506070)
    val darkIron = Color(0xFF25303D)
    val highlight = Color(0xFFFFE080)
    val cyanGlow = PixelPalette.NeonCyan

    Canvas(modifier = modifier.size(size)) {
        val grid = 24
        val pw = this.size.width / grid
        val ph = this.size.height / grid

        fun px(x: Int, y: Int, color: Color) {
            drawRect(
                color = color,
                topLeft = Offset(x * pw, y * ph),
                size = Size(pw + 0.5f, ph + 0.5f)
            )
        }

        // Floating sparkles
        px(4, 4, cyanGlow); px(5, 4, highlight); px(4, 5, highlight)
        px(19, 5, gold); px(20, 5, highlight); px(20, 6, cyanGlow)
        px(2, 14, highlight); px(22, 13, cyanGlow)

        // Chest Outline Black
        for (x in 6..17) { px(x, 7, Color.Black); px(x, 19, Color.Black) }
        for (y in 8..18) { px(5, y, Color.Black); px(18, y, Color.Black) }

        // Chest Lid Curved Top
        for (x in 6..17) {
            px(x, 8, iron)
            for (y in 9..11) {
                px(x, y, wood)
            }
        }
        // Lid Gold bands
        px(8, 8, gold); px(8, 9, gold); px(8, 10, gold); px(8, 11, gold)
        px(15, 8, gold); px(15, 9, gold); px(15, 10, gold); px(15, 11, gold)
        // Highlight on lid
        for (x in 9..14) px(x, 9, highlight.copy(alpha = 0.6f))

        // Center Gold Lock Plate
        for (x in 10..13) {
            for (y in 11..14) px(x, y, gold)
        }
        // Keyhole
        px(11, 12, Color.Black); px(12, 12, Color.Black); px(11, 13, Color.Black)

        // Chest Lower Body
        for (x in 6..17) {
            for (y in 12..18) {
                if (x !in 10..13 || y !in 11..14) {
                    px(x, y, darkWood)
                }
            }
        }
        // Lower Gold bands & corners
        for (y in 12..18) {
            px(6, y, darkIron); px(17, y, darkIron)
            px(8, y, gold); px(15, y, gold)
        }
        // Bottom feet
        for (x in 6..17) px(x, 18, iron)
    }
}
