package com.example.pixeltask.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.pixeltask.data.model.Task
import com.example.pixeltask.data.model.TaskCategoryDefaults
import com.example.pixeltask.data.model.TaskPriority
import com.example.pixeltask.ui.components.PixelButton
import com.example.pixeltask.ui.components.PixelButtonVariant
import com.example.pixeltask.ui.components.PixelCloseIcon
import com.example.pixeltask.ui.components.PixelParticleEffect
import com.example.pixeltask.ui.components.PixelTextField
import com.example.pixeltask.ui.components.pixelCornerShape
import com.example.pixeltask.ui.theme.PixelPalette
import com.example.pixeltask.ui.theme.PixelTheme
import java.util.Calendar

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddEditTaskDialog(
    taskToEdit: Task? = null,
    onDismiss: () -> Unit,
    onSave: (title: String, description: String, category: String, priority: TaskPriority, dueDate: Long?) -> Unit,
    animationEnabled: Boolean = true
) {
    val isEditing = taskToEdit != null

    var title by remember { mutableStateOf(taskToEdit?.title ?: "") }
    var description by remember { mutableStateOf(taskToEdit?.description ?: "") }
    var selectedCategory by remember { mutableStateOf(taskToEdit?.category ?: "WORK") }
    var isCustomCategory by remember { mutableStateOf(false) }
    var customCategoryInput by remember { mutableStateOf("") }
    var selectedPriority by remember { mutableStateOf(taskToEdit?.priority ?: TaskPriority.MEDIUM) }
    var selectedDueDate by remember { mutableStateOf(taskToEdit?.dueDate) }

    var titleError by remember { mutableStateOf<String?>(null) }
    var showSuccessParticles by remember { mutableStateOf(false) }

    fun selectDeadlineDaysFromNow(days: Int) {
        val cal = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, days)
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 0)
        }
        selectedDueDate = cal.timeInMillis
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        val shape = pixelCornerShape(6.dp)

        Box(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .clip(shape)
                .background(PixelTheme.colors.surface)
                .border(3.dp, PixelTheme.colors.border, shape)
                .padding(20.dp)
                .testTag("add_edit_task_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isEditing) "EDIT QUEST" else "NEW QUEST",
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            letterSpacing = 1.sp,
                            color = PixelTheme.colors.primary
                        )
                    )

                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clickable { onDismiss() },
                        contentAlignment = Alignment.Center
                    ) {
                        PixelCloseIcon(size = 16.dp)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Title Input
                PixelTextField(
                    value = title,
                    onValueChange = {
                        title = it
                        if (it.isNotBlank()) titleError = null
                    },
                    label = "Quest Title *",
                    placeholder = "e.g. Slay the project deadline",
                    isError = titleError != null,
                    errorMessage = titleError,
                    modifier = Modifier.testTag("task_title_input")
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Description Input
                PixelTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = "Description",
                    placeholder = "Optional quest details...",
                    singleLine = false,
                    maxLines = 3,
                    modifier = Modifier.testTag("task_desc_input")
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Category Section
                Text(
                    text = "CATEGORY",
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 0.5.sp,
                        color = PixelTheme.colors.textSecondary
                    ),
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val allCategories = TaskCategoryDefaults.PRESETS
                    allCategories.forEach { cat ->
                        val isSelected = !isCustomCategory && selectedCategory.equals(cat, ignoreCase = true)
                        CategoryChip(
                            name = cat,
                            selected = isSelected,
                            onClick = {
                                isCustomCategory = false
                                selectedCategory = cat
                            }
                        )
                    }
                    CategoryChip(
                        name = "+ CUSTOM",
                        selected = isCustomCategory,
                        onClick = { isCustomCategory = true }
                    )
                }

                if (isCustomCategory) {
                    Spacer(modifier = Modifier.height(8.dp))
                    PixelTextField(
                        value = customCategoryInput,
                        onValueChange = { customCategoryInput = it },
                        placeholder = "Enter custom category",
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Priority Section
                Text(
                    text = "PRIORITY",
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 0.5.sp,
                        color = PixelTheme.colors.textSecondary
                    ),
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TaskPriority.entries.forEach { p ->
                        val isSelected = selectedPriority == p
                        val pColor = when (p) {
                            TaskPriority.HIGH -> PixelPalette.NeonPink
                            TaskPriority.MEDIUM -> PixelPalette.NeonYellow
                            TaskPriority.LOW -> PixelPalette.NeonMint
                        }

                        val chipShape = pixelCornerShape(3.dp)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(chipShape)
                                .background(if (isSelected) pColor else PixelTheme.colors.surfaceVariant)
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) Color.Black else PixelTheme.colors.border,
                                    shape = chipShape
                                )
                                .clickable { selectedPriority = p }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = p.label,
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 11.sp,
                                    color = if (isSelected) {
                                        if (p == TaskPriority.HIGH) Color.White else Color.Black
                                    } else {
                                        PixelTheme.colors.textSecondary
                                    }
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Due Date Section
                Text(
                    text = "DEADLINE",
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 0.5.sp,
                        color = PixelTheme.colors.textSecondary
                    ),
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    DateQuickChip(
                        label = "NONE",
                        selected = selectedDueDate == null,
                        onClick = { selectedDueDate = null },
                        modifier = Modifier.weight(1f)
                    )
                    DateQuickChip(
                        label = "TODAY",
                        selected = selectedDueDate != null && isToday(selectedDueDate!!),
                        onClick = { selectDeadlineDaysFromNow(0) },
                        modifier = Modifier.weight(1f)
                    )
                    DateQuickChip(
                        label = "TOMORROW",
                        selected = selectedDueDate != null && isTomorrow(selectedDueDate!!),
                        onClick = { selectDeadlineDaysFromNow(1) },
                        modifier = Modifier.weight(1.2f)
                    )
                }

                Spacer(modifier = Modifier.height(22.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    PixelButton(
                        text = "CANCEL",
                        onClick = onDismiss,
                        variant = PixelButtonVariant.SURFACE,
                        modifier = Modifier.weight(1f),
                        testTag = "cancel_task_button"
                    )

                    PixelButton(
                        text = if (isEditing) "UPDATE" else "CREATE TASK",
                        onClick = {
                            if (title.isBlank()) {
                                titleError = "Task title cannot be empty."
                                return@PixelButton
                            }

                            val category = if (isCustomCategory && customCategoryInput.isNotBlank()) {
                                customCategoryInput.trim().uppercase()
                            } else {
                                selectedCategory
                            }

                            onSave(
                                title.trim(),
                                description.trim(),
                                category,
                                selectedPriority,
                                selectedDueDate
                            )
                        },
                        variant = PixelButtonVariant.PRIMARY,
                        modifier = Modifier.weight(1.3f),
                        testTag = "submit_task_button"
                    )
                }
            }

            // Success Particles
            if (animationEnabled) {
                PixelParticleEffect(
                    trigger = showSuccessParticles,
                    particleCount = 20,
                    durationMs = 500,
                    colors = listOf(PixelPalette.NeonCyan, PixelPalette.NeonMint, PixelPalette.NeonYellow)
                )
            }
        }
    }
}

@Composable
private fun CategoryChip(
    name: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val shape = pixelCornerShape(3.dp)
    val color = if (selected) PixelTheme.colors.primary else PixelTheme.colors.surfaceVariant
    val textColor = if (selected) PixelTheme.colors.onPrimary else PixelTheme.colors.textSecondary

    Box(
        modifier = Modifier
            .clip(shape)
            .background(color)
            .border(1.5.dp, if (selected) PixelTheme.colors.border else PixelTheme.colors.borderShadow, shape)
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 5.dp)
    ) {
        Text(
            text = name,
            style = TextStyle(
                fontFamily = FontFamily.Monospace,
                fontWeight = if (selected) FontWeight.Black else FontWeight.Bold,
                fontSize = 10.sp,
                color = textColor
            )
        )
    }
}

@Composable
private fun DateQuickChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = pixelCornerShape(3.dp)
    val color = if (selected) PixelTheme.colors.accent else PixelTheme.colors.surfaceVariant
    val textColor = if (selected) PixelTheme.colors.onAccent else PixelTheme.colors.textSecondary

    Box(
        modifier = modifier
            .clip(shape)
            .background(color)
            .border(1.5.dp, if (selected) PixelTheme.colors.border else PixelTheme.colors.borderShadow, shape)
            .clickable { onClick() }
            .padding(vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = TextStyle(
                fontFamily = FontFamily.Monospace,
                fontWeight = if (selected) FontWeight.Black else FontWeight.Bold,
                fontSize = 10.sp,
                color = textColor
            )
        )
    }
}

private fun isToday(timestamp: Long): Boolean {
    val now = Calendar.getInstance()
    val check = Calendar.getInstance().apply { timeInMillis = timestamp }
    return now.get(Calendar.YEAR) == check.get(Calendar.YEAR) &&
            now.get(Calendar.DAY_OF_YEAR) == check.get(Calendar.DAY_OF_YEAR)
}

private fun isTomorrow(timestamp: Long): Boolean {
    val now = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) }
    val check = Calendar.getInstance().apply { timeInMillis = timestamp }
    return now.get(Calendar.YEAR) == check.get(Calendar.YEAR) &&
            now.get(Calendar.DAY_OF_YEAR) == check.get(Calendar.DAY_OF_YEAR)
}
