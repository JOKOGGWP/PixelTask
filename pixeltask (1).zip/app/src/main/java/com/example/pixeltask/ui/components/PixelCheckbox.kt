package com.example.pixeltask.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.pixeltask.ui.theme.PixelPalette
import com.example.pixeltask.ui.theme.PixelTheme

@Composable
fun PixelCheckbox(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 26.dp,
    enabled: Boolean = true,
    animationEnabled: Boolean = true
) {
    val scaleAnim by animateFloatAsState(
        targetValue = if (checked && animationEnabled) 1.0f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "checkbox_scale"
    )

    val checkmarkScale by animateFloatAsState(
        targetValue = if (checked) 1f else 0f,
        animationSpec = if (animationEnabled) tween(durationMillis = 250) else tween(durationMillis = 0),
        label = "checkmark_scale"
    )

    val boxColor by animateColorAsState(
        targetValue = if (checked) PixelPalette.NeonMint else PixelTheme.colors.surfaceVariant,
        animationSpec = tween(durationMillis = if (animationEnabled) 200 else 0),
        label = "box_color"
    )

    val borderColor = PixelTheme.colors.border

    Box(
        modifier = modifier
            .size(size)
            .scale(scaleAnim)
            .testTag("pixel_checkbox_${if (checked) "checked" else "unchecked"}")
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = false, radius = 20.dp),
                enabled = enabled,
                role = Role.Checkbox
            ) {
                onCheckedChange(!checked)
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val w = this.size.width
            val h = this.size.height
            val borderW = 2.5f

            // Outer dark stepped border
            drawRect(
                color = borderColor,
                topLeft = Offset(0f, 0f),
                size = Size(w, h)
            )

            // Inner fill
            drawRect(
                color = boxColor,
                topLeft = Offset(borderW, borderW),
                size = Size(w - borderW * 2, h - borderW * 2)
            )

            // If not checked, draw top-left shadow notch for 8-bit depth
            if (!checked) {
                drawRect(
                    color = Color.Black.copy(alpha = 0.25f),
                    topLeft = Offset(borderW, borderW),
                    size = Size(w - borderW * 2, 3f)
                )
            }
        }

        // Stepped Pixel Checkmark
        if (checkmarkScale > 0.01f) {
            Box(
                modifier = Modifier
                    .size(size * 0.75f)
                    .scale(checkmarkScale),
                contentAlignment = Alignment.Center
            ) {
                PixelCheckIcon(
                    size = size * 0.7f,
                    tint = Color.Black // High contrast on bright neon mint
                )
            }
        }
    }
}
