package com.example.pixeltask.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import com.example.pixeltask.data.preferences.AppThemeMode

@Composable
fun PixelTaskTheme(
    themeMode: AppThemeMode = AppThemeMode.DARK,
    content: @Composable () -> Unit
) {
    val isDark = when (themeMode) {
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val pixelColors = if (isDark) DarkPixelColors else LightPixelColors

    val materialColorScheme = if (isDark) {
        darkColorScheme(
            primary = pixelColors.primary,
            onPrimary = pixelColors.onPrimary,
            secondary = pixelColors.secondary,
            onSecondary = pixelColors.onSecondary,
            tertiary = pixelColors.accent,
            background = pixelColors.background,
            surface = pixelColors.surface,
            surfaceVariant = pixelColors.surfaceVariant,
            onBackground = pixelColors.textPrimary,
            onSurface = pixelColors.textPrimary,
            error = pixelColors.danger
        )
    } else {
        lightColorScheme(
            primary = pixelColors.primary,
            onPrimary = pixelColors.onPrimary,
            secondary = pixelColors.secondary,
            onSecondary = pixelColors.onSecondary,
            tertiary = pixelColors.accent,
            background = pixelColors.background,
            surface = pixelColors.surface,
            surfaceVariant = pixelColors.surfaceVariant,
            onBackground = pixelColors.textPrimary,
            onSurface = pixelColors.textPrimary,
            error = pixelColors.danger
        )
    }

    CompositionLocalProvider(
        LocalPixelColors provides pixelColors
    ) {
        MaterialTheme(
            colorScheme = materialColorScheme,
            typography = PixelTypography,
            content = content
        )
    }
}
