package com.example.pixeltask.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.pixeltask.data.preferences.AppThemeMode
import com.example.pixeltask.ui.components.PixelCard
import com.example.pixeltask.ui.components.PixelTopBar
import com.example.pixeltask.ui.components.pixelCornerShape
import com.example.pixeltask.ui.theme.PixelPalette
import com.example.pixeltask.ui.theme.PixelTheme
import com.example.pixeltask.viewmodel.TaskViewModel

@Composable
fun SettingsScreen(
    viewModel: TaskViewModel,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PixelTheme.colors.background)
            .testTag("settings_screen")
    ) {
        PixelTopBar(
            title = "SETTINGS",
            subtitle = "SYSTEM & PREFERENCES"
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Theme Mode Card
            item(key = "theme_settings") {
                PixelCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = PixelTheme.colors.surface,
                    accentColor = PixelTheme.colors.primary
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "VISUAL THEME",
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp,
                                letterSpacing = 1.sp,
                                color = PixelTheme.colors.primary
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ThemeOptionButton(
                                label = "DARK",
                                isSelected = settings.themeMode == AppThemeMode.DARK,
                                onClick = { viewModel.setThemeMode(AppThemeMode.DARK) },
                                modifier = Modifier.weight(1f)
                            )
                            ThemeOptionButton(
                                label = "LIGHT",
                                isSelected = settings.themeMode == AppThemeMode.LIGHT,
                                onClick = { viewModel.setThemeMode(AppThemeMode.LIGHT) },
                                modifier = Modifier.weight(1f)
                            )
                            ThemeOptionButton(
                                label = "SYSTEM",
                                isSelected = settings.themeMode == AppThemeMode.SYSTEM,
                                onClick = { viewModel.setThemeMode(AppThemeMode.SYSTEM) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Toggles Card (Animation, Sound, Vibration)
            item(key = "effects_settings") {
                PixelCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = PixelTheme.colors.surface,
                    accentColor = PixelPalette.NeonCyan
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "EFFECTS & FEEDBACK",
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp,
                                letterSpacing = 1.sp,
                                color = PixelPalette.NeonCyan
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Animation Toggle
                        PixelToggleRow(
                            title = "ANIMATION & PARTICLES",
                            subtitle = "Pixel debris, spring scaling and transitions",
                            isEnabled = settings.animationEnabled,
                            onToggle = { viewModel.setAnimationEnabled(!settings.animationEnabled) }
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Sound Toggle
                        PixelToggleRow(
                            title = "RETRO 8-BIT AUDIO",
                            subtitle = "Arcade synth tones for complete, add and delete",
                            isEnabled = settings.soundEnabled,
                            onToggle = { viewModel.setSoundEnabled(!settings.soundEnabled) }
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Vibration Toggle
                        PixelToggleRow(
                            title = "HAPTIC FEEDBACK",
                            subtitle = "Subtle tactile vibrations on button clicks",
                            isEnabled = settings.vibrationEnabled,
                            onToggle = { viewModel.setVibrationEnabled(!settings.vibrationEnabled) }
                        )
                    }
                }
            }

            // About PixelTask Card
            item(key = "about_card") {
                PixelCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = PixelTheme.colors.surface,
                    accentColor = PixelPalette.NeonMint
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ABOUT PIXELTASK",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 13.sp,
                                    letterSpacing = 1.sp,
                                    color = PixelPalette.NeonMint
                                )
                            )

                            // Version Badge
                            val shape = pixelCornerShape(2.dp)
                            Box(
                                modifier = Modifier
                                    .clip(shape)
                                    .background(PixelPalette.NeonMint)
                                    .border(1.dp, Color.Black, shape)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "v1.0.0",
                                    style = TextStyle(
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 10.sp,
                                        color = Color.Black
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "PixelTask is an offline-first retro game inspired productivity manager. Features modern pixel-art styling, 8-bit particle celebrations, and local persistence powered by Room Database.",
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Normal,
                                fontSize = 11.sp,
                                lineHeight = 16.sp,
                                color = PixelTheme.colors.textSecondary
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Technical specs
                        Text(
                            text = "ENGINE SPECS:",
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                color = PixelTheme.colors.textMuted
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "• Kotlin + Jetpack Compose\n• Material 3 + Custom Pixel Design\n• Room SQLite Database (Offline-First)\n• 8-bit AudioTrack Waveform Synthesizer",
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                lineHeight = 15.sp,
                                color = PixelTheme.colors.textSecondary
                            )
                        )
                    }
                }
            }

            item(key = "bottom_spacer") {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun ThemeOptionButton(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = pixelCornerShape(3.dp)
    val bgColor = if (isSelected) PixelTheme.colors.primary else PixelTheme.colors.surfaceVariant
    val textColor = if (isSelected) PixelTheme.colors.onPrimary else PixelTheme.colors.textSecondary

    Box(
        modifier = modifier
            .clip(shape)
            .background(bgColor)
            .border(1.5.dp, if (isSelected) Color.Black else PixelTheme.colors.border, shape)
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = TextStyle(
                fontFamily = FontFamily.Monospace,
                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                fontSize = 11.sp,
                letterSpacing = 0.5.sp,
                color = textColor
            )
        )
    }
}

@Composable
private fun PixelToggleRow(
    title: String,
    subtitle: String,
    isEnabled: Boolean,
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggle() },
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    letterSpacing = 0.25.sp,
                    color = PixelTheme.colors.textPrimary
                )
            )
            Text(
                text = subtitle,
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Normal,
                    fontSize = 10.sp,
                    color = PixelTheme.colors.textSecondary
                )
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Pixel Switch ON / OFF
        val shape = pixelCornerShape(3.dp)
        val switchBg = if (isEnabled) PixelPalette.NeonMint else PixelTheme.colors.surfaceVariant
        val textColor = if (isEnabled) Color.Black else PixelTheme.colors.textMuted

        Box(
            modifier = Modifier
                .clip(shape)
                .background(switchBg)
                .border(1.5.dp, if (isEnabled) Color.Black else PixelTheme.colors.borderShadow, shape)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = if (isEnabled) "ON" else "OFF",
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 11.sp,
                    letterSpacing = 0.5.sp,
                    color = textColor
                )
            )
        }
    }
}
