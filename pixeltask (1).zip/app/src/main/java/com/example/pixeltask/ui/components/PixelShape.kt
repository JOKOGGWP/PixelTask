package com.example.pixeltask.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

/**
 * Creates an authentic 8-bit stepped pixel corner shape.
 * Cut off corners by [cornerSize] in crisp right-angled steps.
 */
class PixelCornerShape(private val cornerSize: Dp = 6.dp) : Shape {
    override fun createOutline(
        size: Size,
        layoutDirection: LayoutDirection,
        density: Density
    ): Outline {
        val corner = with(density) { cornerSize.toPx() }
        val w = size.width
        val h = size.height

        val path = Path().apply {
            reset()
            // Top-left
            moveTo(corner, 0f)
            // Top edge
            lineTo(w - corner, 0f)
            // Top-right step
            lineTo(w, corner)
            // Right edge
            lineTo(w, h - corner)
            // Bottom-right step
            lineTo(w - corner, h)
            // Bottom edge
            lineTo(corner, h)
            // Bottom-left step
            lineTo(0f, h - corner)
            // Left edge
            lineTo(0f, corner)
            close()
        }
        return Outline.Generic(path)
    }
}

fun pixelCornerShape(cornerSize: Dp = 6.dp): Shape = PixelCornerShape(cornerSize)

fun Modifier.pixelBorder(
    width: Dp = 2.dp,
    color: Color = Color.Black,
    cornerSize: Dp = 6.dp
): Modifier {
    val shape = pixelCornerShape(cornerSize)
    return this
        .clip(shape)
        .border(BorderStroke(width, color), shape)
}
