package com.example.pixeltask.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.pixeltask.ui.theme.PixelTheme

/**
 * Draws crisp pixel art on a coordinate grid (e.g. 16x16).
 */
@Composable
fun PixelIcon(
    gridWidth: Int = 16,
    gridHeight: Int = 16,
    size: Dp = 20.dp,
    tint: Color = PixelTheme.colors.primary,
    modifier: Modifier = Modifier,
    drawPixels: (setPixel: (x: Int, y: Int) -> Unit) -> Unit
) {
    Canvas(modifier = modifier.size(size)) {
        val pixelW = this.size.width / gridWidth
        val pixelH = this.size.height / gridHeight

        drawPixels { x, y ->
            if (x in 0 until gridWidth && y in 0 until gridHeight) {
                drawRect(
                    color = tint,
                    topLeft = Offset(x * pixelW, y * pixelH),
                    size = Size(pixelW + 0.5f, pixelH + 0.5f) // avoid subpixel seams
                )
            }
        }
    }
}

@Composable
fun PixelHomeIcon(
    size: Dp = 20.dp,
    tint: Color = PixelTheme.colors.primary,
    modifier: Modifier = Modifier
) {
    PixelIcon(16, 16, size, tint, modifier) { p ->
        // Roof
        p(7, 2); p(8, 2)
        p(6, 3); p(7, 3); p(8, 3); p(9, 3)
        p(5, 4); p(6, 4); p(9, 4); p(10, 4)
        p(4, 5); p(5, 5); p(10, 5); p(11, 5)
        p(3, 6); p(4, 6); p(11, 6); p(12, 6)
        p(2, 7); p(3, 7); p(12, 7); p(13, 7)
        // Chimney
        p(11, 3); p(12, 3)
        // Walls
        for (y in 8..13) {
            p(3, y); p(4, y)
            p(11, y); p(12, y)
        }
        // Base
        for (x in 3..12) p(x, 13)
        // Door
        for (y in 10..13) {
            p(7, y); p(8, y)
        }
    }
}

@Composable
fun PixelTasksIcon(
    size: Dp = 20.dp,
    tint: Color = PixelTheme.colors.primary,
    modifier: Modifier = Modifier
) {
    PixelIcon(16, 16, size, tint, modifier) { p ->
        // Checklist bullets and lines
        // Bullet 1
        p(2, 3); p(3, 3); p(2, 4); p(3, 4)
        // Line 1
        for (x in 6..14) { p(x, 3); p(x, 4) }
        // Bullet 2 (check mark)
        p(2, 8); p(3, 9); p(4, 8); p(5, 7)
        // Line 2
        for (x in 7..14) { p(x, 8); p(x, 9) }
        // Bullet 3
        p(2, 12); p(3, 12); p(2, 13); p(3, 13)
        // Line 3
        for (x in 6..12) { p(x, 12); p(x, 13) }
    }
}

@Composable
fun PixelStatsIcon(
    size: Dp = 20.dp,
    tint: Color = PixelTheme.colors.primary,
    modifier: Modifier = Modifier
) {
    PixelIcon(16, 16, size, tint, modifier) { p ->
        // Bar 1 (height 4)
        for (y in 10..13) { p(2, y); p(3, y) }
        // Bar 2 (height 8)
        for (y in 6..13) { p(5, y); p(6, y) }
        // Bar 3 (height 11)
        for (y in 3..13) { p(8, y); p(9, y) }
        // Bar 4 (height 6)
        for (y in 8..13) { p(11, y); p(12, y) }
        // Base line
        for (x in 1..14) p(x, 14)
    }
}

@Composable
fun PixelSettingsIcon(
    size: Dp = 20.dp,
    tint: Color = PixelTheme.colors.primary,
    modifier: Modifier = Modifier
) {
    PixelIcon(16, 16, size, tint, modifier) { p ->
        // Gear teeth
        p(7, 1); p(8, 1); p(7, 2); p(8, 2)
        p(7, 13); p(8, 13); p(7, 14); p(8, 14)
        p(1, 7); p(1, 8); p(2, 7); p(2, 8)
        p(13, 7); p(13, 8); p(14, 7); p(14, 8)
        // Diagonal teeth
        p(3, 3); p(4, 4); p(11, 4); p(12, 3)
        p(3, 12); p(4, 11); p(11, 11); p(12, 12)
        // Gear body circle
        for (x in 5..10) { p(x, 3); p(x, 12) }
        for (y in 5..10) { p(3, y); p(12, y) }
        for (x in 4..11) {
            for (y in 4..11) {
                // Cut center hole (6..9, 6..9)
                if (x !in 6..9 || y !in 6..9) {
                    p(x, y)
                }
            }
        }
    }
}

@Composable
fun PixelPlusIcon(
    size: Dp = 16.dp,
    tint: Color = Color.Black,
    modifier: Modifier = Modifier
) {
    PixelIcon(12, 12, size, tint, modifier) { p ->
        for (y in 2..9) { p(5, y); p(6, y) }
        for (x in 2..9) { p(x, 5); p(x, 6) }
    }
}

@Composable
fun PixelCheckIcon(
    size: Dp = 16.dp,
    tint: Color = PixelTheme.colors.success,
    modifier: Modifier = Modifier
) {
    PixelIcon(14, 14, size, tint, modifier) { p ->
        p(2, 7); p(2, 8)
        p(3, 8); p(3, 9)
        p(4, 9); p(4, 10)
        p(5, 10); p(5, 11)
        p(6, 9); p(6, 10)
        p(7, 8); p(7, 9)
        p(8, 7); p(8, 8)
        p(9, 6); p(9, 7)
        p(10, 5); p(10, 6)
        p(11, 4); p(11, 5)
        p(12, 3); p(12, 4)
    }
}

@Composable
fun PixelTrashIcon(
    size: Dp = 18.dp,
    tint: Color = PixelTheme.colors.danger,
    modifier: Modifier = Modifier
) {
    PixelIcon(16, 16, size, tint, modifier) { p ->
        // Handle
        p(7, 1); p(8, 1)
        // Lid
        for (x in 3..12) p(x, 3)
        // Can body
        for (y in 4..13) {
            p(4, y); p(11, y)
        }
        // Base
        for (x in 4..11) p(x, 13)
        // Vertical ribs
        for (y in 6..11) {
            p(6, y); p(9, y)
        }
    }
}

@Composable
fun PixelEditIcon(
    size: Dp = 16.dp,
    tint: Color = PixelTheme.colors.primary,
    modifier: Modifier = Modifier
) {
    PixelIcon(16, 16, size, tint, modifier) { p ->
        // Diagonal pencil
        p(13, 1); p(14, 2); p(12, 2); p(13, 3)
        p(11, 3); p(12, 4); p(10, 4); p(11, 5)
        p(9, 5); p(10, 6); p(8, 6); p(9, 7)
        p(7, 7); p(8, 8); p(6, 8); p(7, 9)
        p(5, 9); p(6, 10); p(4, 10); p(5, 11)
        p(3, 11); p(4, 12); p(2, 12); p(3, 13)
        // Tip
        p(1, 14); p(2, 13)
        // Base line
        for (x in 5..14) p(x, 14)
    }
}

@Composable
fun PixelTrophyIcon(
    size: Dp = 20.dp,
    tint: Color = PixelTheme.colors.accent,
    modifier: Modifier = Modifier
) {
    PixelIcon(16, 16, size, tint, modifier) { p ->
        // Cup rim
        for (x in 4..11) p(x, 2)
        // Cup body
        for (y in 3..6) {
            for (x in 4..11) p(x, y)
        }
        // Cup bottom taper
        for (x in 5..10) p(x, 7)
        for (x in 6..9) p(x, 8)
        // Handles
        p(2, 3); p(3, 3); p(2, 4); p(2, 5); p(3, 6)
        p(12, 6); p(13, 5); p(13, 4); p(12, 3); p(13, 3)
        // Stem
        p(7, 9); p(8, 9); p(7, 10); p(8, 10)
        // Base
        for (x in 4..11) p(x, 11)
        for (x in 3..12) p(x, 12)
    }
}

@Composable
fun PixelSearchIcon(
    size: Dp = 16.dp,
    tint: Color = PixelTheme.colors.primary,
    modifier: Modifier = Modifier
) {
    PixelIcon(16, 16, size, tint, modifier) { p ->
        // Lens circle
        for (x in 4..8) { p(x, 2); p(x, 8) }
        for (y in 4..6) { p(2, y); p(10, y) }
        p(3, 3); p(9, 3); p(3, 7); p(9, 7)
        // Handle
        p(10, 10); p(11, 11); p(12, 12); p(13, 13); p(14, 14)
        p(11, 10); p(12, 11); p(13, 12)
    }
}

@Composable
fun PixelCloseIcon(
    size: Dp = 16.dp,
    tint: Color = PixelTheme.colors.textPrimary,
    modifier: Modifier = Modifier
) {
    PixelIcon(12, 12, size, tint, modifier) { p ->
        p(2, 2); p(3, 3); p(4, 4); p(5, 5); p(6, 6); p(7, 7); p(8, 8); p(9, 9)
        p(2, 3); p(3, 2); p(8, 9); p(9, 8)
        p(9, 2); p(8, 3); p(7, 4); p(6, 5); p(5, 6); p(4, 7); p(3, 8); p(2, 9)
        p(8, 2); p(9, 3); p(2, 8); p(3, 9)
    }
}
