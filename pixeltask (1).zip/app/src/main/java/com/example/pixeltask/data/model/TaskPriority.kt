package com.example.pixeltask.data.model

enum class TaskPriority(val label: String, val level: Int) {
    LOW("LOW", 1),
    MEDIUM("MED", 2),
    HIGH("HIGH", 3);

    companion object {
        fun fromString(value: String): TaskPriority {
            return entries.firstOrNull { it.name.equals(value, ignoreCase = true) || it.label.equals(value, ignoreCase = true) }
                ?: MEDIUM
        }
    }
}
