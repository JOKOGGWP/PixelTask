package com.example.pixeltask.ui.theme

import androidx.compose.ui.graphics.Color

// Pixel Retro Arcade Palette
object PixelPalette {
    // Dark Theme Colors
    val DarkBackground = Color(0xFF0D1117)
    val DarkSurface = Color(0xFF161B26)
    val DarkSurfaceVariant = Color(0xFF212838)
    val DarkSurfaceElevated = Color(0xFF283246)
    
    // Light Theme Colors
    val LightBackground = Color(0xFFEBF0F5)
    val LightSurface = Color(0xFFFFFFFF)
    val LightSurfaceVariant = Color(0xFFDFE6EE)
    val LightSurfaceElevated = Color(0xFFD3DDE8)

    // Vibrant Arcade Accents
    val NeonCyan = Color(0xFF00E5FF)       // Electric Cyan
    val NeonMint = Color(0xFF00E676)       // Bright 8-bit Green / Success
    val NeonYellow = Color(0xFFFFD600)     // Arcade Gold / Warning
    val NeonPink = Color(0xFFFF2A6D)       // Hot Arcade Magenta / Danger / Secondary
    val NeonPurple = Color(0xFF9D4EDD)     // 16-bit Violet
    val NeonOrange = Color(0xFFFF6D00)     // Quest Amber
    
    // Border & Bevel Colors
    val DarkBorder = Color(0xFF000000)
    val DarkBorderHighlight = Color(0xFF3B4860)
    val DarkBorderShadow = Color(0xFF070A0F)

    val LightBorder = Color(0xFF1E293B)
    val LightBorderHighlight = Color(0xFFFFFFFF)
    val LightBorderShadow = Color(0xFF94A3B8)

    // Text
    val TextLightPrimary = Color(0xFF0F172A)
    val TextLightSecondary = Color(0xFF475569)
    val TextLightMuted = Color(0xFF64748B)

    val TextDarkPrimary = Color(0xFFF8FAFC)
    val TextDarkSecondary = Color(0xFF94A3B8)
    val TextDarkMuted = Color(0xFF64748B)

    // Category Color Tags
    val CatWork = Color(0xFF00B4D8)
    val CatPersonal = Color(0xFF9D4EDD)
    val CatGame = Color(0xFFFF2A6D)
    val CatStudy = Color(0xFFFFD600)
    val CatHealth = Color(0xFF00E676)
    val CatOther = Color(0xFFFF8500)
}
