package com.example.pixeltask.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

data class PixelColors(
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val surfaceElevated: Color,
    val primary: Color,
    val onPrimary: Color,
    val secondary: Color,
    val onSecondary: Color,
    val accent: Color,
    val onAccent: Color,
    val success: Color,
    val warning: Color,
    val danger: Color,
    val border: Color,
    val borderHighlight: Color,
    val borderShadow: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val pixelGrid: Color,
    val isDark: Boolean
)

val DarkPixelColors = PixelColors(
    background = PixelPalette.DarkBackground,
    surface = PixelPalette.DarkSurface,
    surfaceVariant = PixelPalette.DarkSurfaceVariant,
    surfaceElevated = PixelPalette.DarkSurfaceElevated,
    primary = PixelPalette.NeonCyan,
    onPrimary = Color(0xFF001F29),
    secondary = PixelPalette.NeonPink,
    onSecondary = Color(0xFFFFFFFF),
    accent = PixelPalette.NeonYellow,
    onAccent = Color(0xFF1E1A00),
    success = PixelPalette.NeonMint,
    warning = PixelPalette.NeonYellow,
    danger = PixelPalette.NeonPink,
    border = PixelPalette.DarkBorder,
    borderHighlight = PixelPalette.DarkBorderHighlight,
    borderShadow = PixelPalette.DarkBorderShadow,
    textPrimary = PixelPalette.TextDarkPrimary,
    textSecondary = PixelPalette.TextDarkSecondary,
    textMuted = PixelPalette.TextDarkMuted,
    pixelGrid = Color(0x1A00E5FF),
    isDark = true
)

val LightPixelColors = PixelColors(
    background = PixelPalette.LightBackground,
    surface = PixelPalette.LightSurface,
    surfaceVariant = PixelPalette.LightSurfaceVariant,
    surfaceElevated = PixelPalette.LightSurfaceElevated,
    primary = Color(0xFF0284C7), // Vibrant Deep Cyan
    onPrimary = Color(0xFFFFFFFF),
    secondary = Color(0xFFE11D48), // Deep Arcade Rose
    onSecondary = Color(0xFFFFFFFF),
    accent = Color(0xFFD97706),
    onAccent = Color(0xFFFFFFFF),
    success = Color(0xFF16A34A),
    warning = Color(0xFFD97706),
    danger = Color(0xFFDC2626),
    border = PixelPalette.LightBorder,
    borderHighlight = PixelPalette.LightBorderHighlight,
    borderShadow = PixelPalette.LightBorderShadow,
    textPrimary = PixelPalette.TextLightPrimary,
    textSecondary = PixelPalette.TextLightSecondary,
    textMuted = PixelPalette.TextLightMuted,
    pixelGrid = Color(0x150F172A),
    isDark = false
)

val LocalPixelColors = staticCompositionLocalOf { DarkPixelColors }

object PixelTheme {
    val colors: PixelColors
        @Composable
        @ReadOnlyComposable
        get() = LocalPixelColors.current
}
