package com.example.pixeltask.data.sound

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.sin

class RetroSoundPlayer(private val context: Context) {
    private val scope = CoroutineScope(Dispatchers.Default)

    private val vibrator: Vibrator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    /**
     * Play rising retro 8-bit chime for Task Completed:
     * C5 (523Hz) -> E5 (659Hz) -> G5 (784Hz) -> C6 (1046Hz)
     */
    fun playTaskCompleted(soundEnabled: Boolean, vibrationEnabled: Boolean) {
        if (vibrationEnabled) {
            vibrate(50)
        }
        if (!soundEnabled) return

        scope.launch {
            val notes = listOf(523.25, 659.25, 783.99, 1046.50)
            val durationPerNoteMs = 45
            playArpeggio(notes, durationPerNoteMs)
        }
    }

    /**
     * Play snappy high 8-bit coin blip for Task Created:
     * A5 (880Hz) -> E6 (1318Hz)
     */
    fun playTaskCreated(soundEnabled: Boolean, vibrationEnabled: Boolean) {
        if (vibrationEnabled) {
            vibrate(30)
        }
        if (!soundEnabled) return

        scope.launch {
            val notes = listOf(880.0, 1318.5)
            val durationPerNoteMs = 40
            playArpeggio(notes, durationPerNoteMs)
        }
    }

    /**
     * Play retro descending tone for Task Deleted:
     * 440Hz -> 293Hz -> 146Hz
     */
    fun playTaskDeleted(soundEnabled: Boolean, vibrationEnabled: Boolean) {
        if (vibrationEnabled) {
            vibrate(40)
        }
        if (!soundEnabled) return

        scope.launch {
            val notes = listOf(440.0, 293.66, 146.83)
            val durationPerNoteMs = 50
            playArpeggio(notes, durationPerNoteMs)
        }
    }

    /**
     * Tiny click sound for button interaction
     */
    fun playButtonClick(soundEnabled: Boolean, vibrationEnabled: Boolean) {
        if (vibrationEnabled) {
            vibrate(15)
        }
        if (!soundEnabled) return

        scope.launch {
            playTone(880.0, 20)
        }
    }

    private fun vibrate(durationMs: Long) {
        try {
            vibrator?.let { v ->
                if (v.hasVibrator()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
                    } else {
                        @Suppress("DEPRECATION")
                        v.vibrate(durationMs)
                    }
                }
            }
        } catch (_: Exception) {
            // Ignore vibration failure
        }
    }

    private fun playArpeggio(frequencies: List<Double>, noteDurationMs: Int) {
        try {
            val sampleRate = 22050
            val totalSamples = frequencies.size * (sampleRate * noteDurationMs / 1000)
            val buffer = ShortArray(totalSamples)
            var offset = 0

            for (freq in frequencies) {
                val samplesForNote = sampleRate * noteDurationMs / 1000
                for (i in 0 until samplesForNote) {
                    val angle = 2.0 * Math.PI * i / (sampleRate / freq)
                    // Square wave with slight duty cycle variation for authentic 8-bit sound
                    val value = if (sin(angle) >= 0.0) 8000 else -8000
                    // Decay envelope
                    val envelope = (samplesForNote - i).toDouble() / samplesForNote.toDouble()
                    buffer[offset + i] = (value * envelope).toInt().toShort()
                }
                offset += samplesForNote
            }

            writeAndPlay(buffer, sampleRate)
        } catch (_: Exception) {
            // Safe fallback
        }
    }

    private fun playTone(freq: Double, durationMs: Int) {
        try {
            val sampleRate = 22050
            val totalSamples = sampleRate * durationMs / 1000
            val buffer = ShortArray(totalSamples)

            for (i in 0 until totalSamples) {
                val angle = 2.0 * Math.PI * i / (sampleRate / freq)
                val value = if (sin(angle) >= 0.0) 7000 else -7000
                val envelope = (totalSamples - i).toDouble() / totalSamples.toDouble()
                buffer[i] = (value * envelope).toInt().toShort()
            }

            writeAndPlay(buffer, sampleRate)
        } catch (_: Exception) {
            // Safe fallback
        }
    }

    private fun writeAndPlay(buffer: ShortArray, sampleRate: Int) {
        var track: AudioTrack? = null
        try {
            val bufferSize = buffer.size * 2
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()

            val audioFormat = AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()

            track = AudioTrack.Builder()
                .setAudioAttributes(audioAttributes)
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(buffer, 0, buffer.size)
            track.play()
            Thread.sleep((buffer.size.toDouble() / sampleRate * 1000).toLong() + 20)
        } catch (_: Exception) {
            // Ignore audio generation error
        } finally {
            try {
                track?.stop()
                track?.release()
            } catch (_: Exception) {
                // Ignore
            }
        }
    }
}
