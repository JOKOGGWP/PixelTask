package com.example.pixeltask.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pixeltask.ui.theme.PixelTheme

enum class NavDestination(val label: String) {
    HOME("HOME"),
    TASKS("TASKS"),
    STATS("STATS"),
    SETTINGS("SETTINGS")
}

@Composable
fun PixelBottomBar(
    currentDestination: NavDestination,
    onNavigate: (NavDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    val borderColor = PixelTheme.colors.border

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(PixelTheme.colors.surface)
            .drawBehind {
                val strokeW = 2.dp.toPx()
                drawLine(
                    color = borderColor,
                    start = Offset(0f, 0f),
                    end = Offset(size.width, 0f),
                    strokeWidth = strokeW
                )
            }
            .navigationBarsPadding()
            .padding(vertical = 6.dp)
            .testTag("pixel_bottom_bar")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavDestination.entries.forEach { dest ->
                val isSelected = currentDestination == dest
                val contentColor by animateColorAsState(
                    targetValue = if (isSelected) PixelTheme.colors.primary else PixelTheme.colors.textMuted,
                    label = "nav_color"
                )

                Column(
                    modifier = Modifier
                        .testTag("nav_item_${dest.name.lowercase()}")
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            onNavigate(dest)
                        }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    when (dest) {
                        NavDestination.HOME -> PixelHomeIcon(size = 20.dp, tint = contentColor)
                        NavDestination.TASKS -> PixelTasksIcon(size = 20.dp, tint = contentColor)
                        NavDestination.STATS -> PixelStatsIcon(size = 20.dp, tint = contentColor)
                        NavDestination.SETTINGS -> PixelSettingsIcon(size = 20.dp, tint = contentColor)
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = dest.label,
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                            fontSize = 10.sp,
                            letterSpacing = 0.5.sp,
                            color = contentColor
                        )
                    )

                    // Small pixel indicator dot under selected tab
                    if (isSelected) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Box(
                            modifier = Modifier
                                .height(2.dp)
                                .fillMaxWidth(0.5f)
                                .background(PixelTheme.colors.primary)
                        )
                    }
                }
            }
        }
    }
}
