package com.example.pixeltask.data.model

object TaskCategoryDefaults {
    val PRESETS = listOf(
        "WORK",
        "PERSONAL",
        "GAME",
        "STUDY",
        "HEALTH",
        "OTHER"
    )
}

enum class TaskFilter(val label: String) {
    ALL("ALL"),
    ACTIVE("ACTIVE"),
    COMPLETED("DONE")
}

enum class TaskSort(val label: String) {
    NEWEST("NEWEST"),
    OLDEST("OLDEST"),
    PRIORITY("PRIORITY"),
    DUE_DATE("DEADLINE")
}
