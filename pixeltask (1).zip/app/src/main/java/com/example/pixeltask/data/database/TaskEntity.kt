package com.example.pixeltask.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.pixeltask.data.model.Task
import com.example.pixeltask.data.model.TaskPriority

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val category: String = "OTHER",
    val priority: String = "MEDIUM",
    val dueDate: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val completed: Boolean = false,
    val colorTag: String? = null
) {
    fun toDomain(): Task = Task(
        id = id,
        title = title,
        description = description,
        category = category,
        priority = TaskPriority.fromString(priority),
        dueDate = dueDate,
        createdAt = createdAt,
        completed = completed,
        colorTag = colorTag
    )

    companion object {
        fun fromDomain(task: Task): TaskEntity = TaskEntity(
            id = task.id,
            title = task.title,
            description = task.description,
            category = task.category,
            priority = task.priority.name,
            dueDate = task.dueDate,
            createdAt = task.createdAt,
            completed = task.completed,
            colorTag = task.colorTag
        )
    }
}
