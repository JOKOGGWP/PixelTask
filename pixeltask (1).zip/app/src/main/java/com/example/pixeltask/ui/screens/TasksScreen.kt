package com.example.pixeltask.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.pixeltask.data.model.Task
import com.example.pixeltask.data.model.TaskCategoryDefaults
import com.example.pixeltask.data.model.TaskFilter
import com.example.pixeltask.data.model.TaskSort
import com.example.pixeltask.ui.components.PixelButton
import com.example.pixeltask.ui.components.PixelButtonVariant
import com.example.pixeltask.ui.components.PixelCloseIcon
import com.example.pixeltask.ui.components.PixelEmptyState
import com.example.pixeltask.ui.components.PixelPlusIcon
import com.example.pixeltask.ui.components.PixelSearchIcon
import com.example.pixeltask.ui.components.PixelTaskItem
import com.example.pixeltask.ui.components.PixelTextField
import com.example.pixeltask.ui.components.PixelTopBar
import com.example.pixeltask.ui.components.pixelCornerShape
import com.example.pixeltask.ui.theme.PixelPalette
import com.example.pixeltask.ui.theme.PixelTheme
import com.example.pixeltask.viewmodel.TaskViewModel

@Composable
fun TasksScreen(
    viewModel: TaskViewModel,
    onOpenAddTask: () -> Unit,
    onOpenEditTask: (Task) -> Unit,
    modifier: Modifier = Modifier
) {
    val tasks by viewModel.displayedTasks.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedFilter by viewModel.selectedFilter.collectAsStateWithLifecycle()
    val selectedSort by viewModel.selectedSort.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PixelTheme.colors.background)
            .testTag("tasks_screen")
    ) {
        PixelTopBar(
            title = "ALL QUESTS",
            subtitle = "${tasks.size} MATCHING",
            actions = {
                PixelButton(
                    text = "+ NEW",
                    onClick = onOpenAddTask,
                    variant = PixelButtonVariant.PRIMARY,
                    icon = { PixelPlusIcon(size = 12.dp) },
                    testTag = "tasks_quick_add_button"
                )
            }
        )

        // Search & Filter Panel
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(PixelTheme.colors.surface)
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            // Local Search Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                PixelTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    placeholder = "Search quests by name, desc, tag...",
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("tasks_search_field")
                )

                if (searchQuery.isNotEmpty()) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(PixelTheme.colors.surfaceVariant)
                            .border(1.5.dp, PixelTheme.colors.border)
                            .clickable { viewModel.setSearchQuery("") },
                        contentAlignment = Alignment.Center
                    ) {
                        PixelCloseIcon(size = 14.dp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Status Filters: ALL / ACTIVE / COMPLETED
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TaskFilter.entries.forEach { filter ->
                    val isSelected = selectedFilter == filter
                    FilterButton(
                        label = filter.label,
                        isSelected = isSelected,
                        onClick = { viewModel.setFilter(filter) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Sort Selector Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SORT:",
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        letterSpacing = 0.5.sp,
                        color = PixelTheme.colors.textSecondary
                    ),
                    modifier = Modifier.padding(end = 2.dp)
                )

                TaskSort.entries.forEach { sort ->
                    val isSelected = selectedSort == sort
                    ChipButton(
                        label = sort.label,
                        isSelected = isSelected,
                        onClick = { viewModel.setSort(sort) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Category Horizontal Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TAG:",
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        letterSpacing = 0.5.sp,
                        color = PixelTheme.colors.textSecondary
                    ),
                    modifier = Modifier.padding(end = 2.dp)
                )

                ChipButton(
                    label = "ALL",
                    isSelected = selectedCategory == null,
                    onClick = { viewModel.setCategory(null) }
                )

                TaskCategoryDefaults.PRESETS.forEach { cat ->
                    ChipButton(
                        label = cat,
                        isSelected = selectedCategory.equals(cat, ignoreCase = true),
                        onClick = { viewModel.setCategory(cat) }
                    )
                }
            }
        }

        // List of filtered tasks
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (tasks.isEmpty()) {
                item(key = "empty_state") {
                    PixelEmptyState(
                        title = "NO MATCHING QUESTS",
                        subtitle = if (searchQuery.isNotBlank()) {
                            "No quest matches \"$searchQuery\". Try another keyword!"
                        } else {
                            "No quests in this category or filter."
                        },
                        onNewTaskClick = onOpenAddTask
                    )
                }
            } else {
                items(tasks, key = { it.id }) { task ->
                    PixelTaskItem(
                        task = task,
                        onToggleComplete = { completed ->
                            viewModel.toggleTaskComplete(task, completed)
                        },
                        onEdit = { onOpenEditTask(task) },
                        onDelete = { viewModel.deleteTask(task) },
                        animationEnabled = settings.animationEnabled
                    )
                }
            }

            item(key = "bottom_spacer") {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun FilterButton(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = pixelCornerShape(3.dp)
    val bgColor = if (isSelected) PixelTheme.colors.primary else PixelTheme.colors.surfaceVariant
    val textColor = if (isSelected) PixelTheme.colors.onPrimary else PixelTheme.colors.textSecondary

    Box(
        modifier = modifier
            .clip(shape)
            .background(bgColor)
            .border(1.5.dp, if (isSelected) Color.Black else PixelTheme.colors.border, shape)
            .clickable { onClick() }
            .padding(vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = TextStyle(
                fontFamily = FontFamily.Monospace,
                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                fontSize = 11.sp,
                letterSpacing = 0.5.sp,
                color = textColor
            )
        )
    }
}

@Composable
private fun ChipButton(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val shape = pixelCornerShape(2.dp)
    val bgColor = if (isSelected) PixelPalette.NeonYellow else PixelTheme.colors.surfaceVariant
    val textColor = if (isSelected) Color.Black else PixelTheme.colors.textSecondary

    Box(
        modifier = Modifier
            .clip(shape)
            .background(bgColor)
            .border(1.dp, if (isSelected) Color.Black else PixelTheme.colors.borderShadow, shape)
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = TextStyle(
                fontFamily = FontFamily.Monospace,
                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                fontSize = 10.sp,
                color = textColor
            )
        )
    }
}
