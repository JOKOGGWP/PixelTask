package com.example.pixeltask.data.model

data class Task(
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val category: String = "OTHER",
    val priority: TaskPriority = TaskPriority.MEDIUM,
    val dueDate: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val completed: Boolean = false,
    val colorTag: String? = null
)
