package com.example.pixeltask.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pixeltask.ui.theme.PixelTheme

enum class PixelButtonVariant {
    PRIMARY,
    SECONDARY,
    SUCCESS,
    DANGER,
    ACCENT,
    SURFACE
}

@Composable
fun PixelButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    variant: PixelButtonVariant = PixelButtonVariant.PRIMARY,
    enabled: Boolean = true,
    icon: (@Composable () -> Unit)? = null,
    testTag: String = "pixel_button"
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val colors = PixelTheme.colors
    val (buttonColor, contentColor, shadowColor) = when (variant) {
        PixelButtonVariant.PRIMARY -> Triple(colors.primary, colors.onPrimary, Color(0xFF00758F))
        PixelButtonVariant.SECONDARY -> Triple(colors.secondary, colors.onSecondary, Color(0xFF9E0038))
        PixelButtonVariant.SUCCESS -> Triple(colors.success, Color.Black, Color(0xFF008F47))
        PixelButtonVariant.DANGER -> Triple(colors.danger, Color.White, Color(0xFF9E002B))
        PixelButtonVariant.ACCENT -> Triple(colors.accent, colors.onAccent, Color(0xFF996500))
        PixelButtonVariant.SURFACE -> Triple(colors.surfaceElevated, colors.textPrimary, colors.borderShadow)
    }

    val shadowHeight = 4.dp
    val pressOffset by animateDpAsState(
        targetValue = if (isPressed && enabled) shadowHeight else 0.dp,
        animationSpec = tween(durationMillis = 50),
        label = "button_press"
    )

    val shape = pixelCornerShape(4.dp)
    val borderColor = colors.border

    Box(
        modifier = modifier
            .testTag(testTag)
            .padding(bottom = shadowHeight)
            .drawBehind {
                // Bottom retro 3D shadow
                val w = this.size.width
                val h = this.size.height
                val shadowPx = shadowHeight.toPx()
                drawRect(
                    color = borderColor,
                    topLeft = Offset(0f, shadowPx),
                    size = Size(w, h)
                )
                drawRect(
                    color = shadowColor,
                    topLeft = Offset(2.dp.toPx(), shadowPx),
                    size = Size(w - 4.dp.toPx(), h - 2.dp.toPx())
                )
            }
            .offset(y = pressOffset)
            .clip(shape)
            .background(if (enabled) buttonColor else colors.surfaceVariant)
            .border(2.dp, borderColor, shape)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = enabled,
                onClick = onClick
            )
            .defaultMinSize(minHeight = 44.dp)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (icon != null) {
                icon()
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text,
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp,
                    letterSpacing = 0.8.sp,
                    color = if (enabled) contentColor else colors.textMuted
                )
            )
        }
    }
}
